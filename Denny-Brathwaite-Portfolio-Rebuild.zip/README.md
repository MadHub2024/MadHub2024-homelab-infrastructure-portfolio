# Denny Brathwaite — Homelab Infrastructure Portfolio

A recruiter-focused static portfolio documenting practical work in:

- TP-Link Omada networking and VLAN segmentation
- Linux administration and Docker Compose
- Technitium DNS and AdGuard Home
- Caddy reverse proxy, TLS, and internal PKI
- LibreNMS, Prometheus, Grafana, exporters, and Uptime Kuma
- Vaultwarden recovery and security hardening

## Deployment

This repository is suitable for Cloudflare Workers/Pages static deployment.

## Primary files

- `index.html`
- `network-segmentation.html`
- `dns-architecture.html`
- `tls-architecture.html`
- `monitoring-stack.html`
- `vaultwarden-recovery.html`
- `certificates.html`
- `styles.css`
- `script.js`

## Live site

`https://portfolio.dbservicessolutions.org`
